-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: i8d211.p.ssafy.io    Database: metassafy
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `chatroom`
--

DROP TABLE IF EXISTS `chatroom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chatroom` (
  `croom_no` int NOT NULL AUTO_INCREMENT,
  `croom_name` varchar(200) NOT NULL,
  `last_chat` text,
  `croom_img` varchar(2500) DEFAULT 'https://st2.depositphotos.com/1005738/6994/i/600/depositphotos_69949201-stock-photo-wild-grass-at-summer-sunset.jpg',
  `regtime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`croom_no`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chatroom`
--

LOCK TABLES `chatroom` WRITE;
/*!40000 ALTER TABLE `chatroom` DISABLE KEYS */;
INSERT INTO `chatroom` VALUES (16,'최지원, 김싸피','하이하이하이','https://kr.object.ncloudstorage.com/metassafy/2979592c-15da-425c-a314-ccc8b56063e9blob','2023-02-16 13:24:12'),(17,'이햇살, 오주영','나 지금 로비인데 나 보러와??','https://kr.object.ncloudstorage.com/metassafy/8900a9f6-6244-4a11-bb3a-cd5e54f896dfblob','2023-02-16 13:32:30'),(18,'이햇살, 오주영','오키오키!','https://kr.object.ncloudstorage.com/metassafy/e6220e85-608f-4dd6-b4e5-12977a1b47f0blob','2023-02-16 13:33:41'),(19,'최지원, 이햇살, 오주영','너무 좋아요?','https://kr.object.ncloudstorage.com/metassafy/ec86e757-c9d1-4458-a458-928b6d631f3dblob','2023-02-16 13:46:32'),(20,'이석원, 이햇살','비지엠 틀어봐','https://kr.object.ncloudstorage.com/metassafy/0cdbdf9b-1ee1-415c-a160-edb82eee6c58blob','2023-02-16 15:25:17');
/*!40000 ALTER TABLE `chatroom` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17  9:07:47
