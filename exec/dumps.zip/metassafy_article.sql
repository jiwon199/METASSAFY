-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: i8d211.p.ssafy.io    Database: metassafy
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `article`
--

DROP TABLE IF EXISTS `article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `article` (
  `article_no` int NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `content` text NOT NULL,
  `hit` int NOT NULL DEFAULT '0',
  `regtime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modtime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `thumbnail` varchar(2500) DEFAULT NULL,
  PRIMARY KEY (`article_no`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `article_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `User` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article`
--

LOCK TABLES `article` WRITE;
/*!40000 ALTER TABLE `article` DISABLE KEYS */;
INSERT INTO `article` VALUES (6,'admin','ㅎㅎ','ㅎㅎㅎㅎ',27,'2023-02-13 08:43:51','2023-02-13 08:43:51','https://kr.object.ncloudstorage.com/metassafy/46fd4dda-f268-4050-80cb-ae677a5ed7da다운로드 (5).jfif'),(11,'admin','친구를 사겼습니다..','친구',20,'2023-02-16 04:47:06','2023-02-16 12:20:07','https://kr.object.ncloudstorage.com/metassafy/48cfe6c5-4167-4425-9acf-670fb510e98aimage-download (6).png'),(12,'0824591','ㅎㅎ','ㅎㅎㅎ',18,'2023-02-16 10:37:57','2023-02-16 10:40:47','https://kr.object.ncloudstorage.com/metassafy/51907c64-f86c-4ca4-a48d-2bf2b54037c3dog1.jfif'),(13,'0820723','외딴 섬에 갇혔어요','살려주세요',7,'2023-02-16 12:44:14','2023-02-16 12:44:14','https://kr.object.ncloudstorage.com/metassafy/db39bbd8-984e-4c72-8976-2b63c87d8c61Image Pasted at 2023-2-16 10-30.png'),(15,'0825647','하위','하위하위',3,'2023-02-16 13:52:26','2023-02-16 13:52:38','https://kr.object.ncloudstorage.com/metassafy/eff0676e-ec28-4919-aa5c-11a209f2ce52eqwweqw.PNG'),(16,'0825647','[전국] JAVA 알고리즘 스터디 구합니다','전국 단위로 구해요',0,'2023-02-16 13:53:09','2023-02-16 13:53:09',NULL),(17,'0826603','[구미] 스프링 공부 같이 하실 분','있다면 저에게 연락주세요',7,'2023-02-16 14:06:57','2023-02-16 14:06:57','https://kr.object.ncloudstorage.com/metassafy/15c7a295-2dc3-45f7-b70c-b4c83e05c3acimage-download (4).png'),(18,'0824591','하핫','안녕하세요!?',2,'2023-02-16 14:07:36','2023-02-16 14:07:36','https://kr.object.ncloudstorage.com/metassafy/c9ca62e8-a4c9-4ec1-a6e4-cdddea844d7c다운로드 (4).jfif'),(19,'0825647','쨘쨘','짠합시다',3,'2023-02-16 14:17:03','2023-02-16 14:17:03','https://kr.object.ncloudstorage.com/metassafy/6f669e46-f21f-418e-9bc0-e6f399162c96cheers.png'),(20,'0820000','안녕하세요 김싸피입니다','친구하실분? ㅎㅎ',0,'2023-02-16 23:58:14','2023-02-16 23:58:14','https://kr.object.ncloudstorage.com/metassafy/259ad9ff-a7d0-4c83-b905-a7f868ecc58czz.png');
/*!40000 ALTER TABLE `article` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17  9:07:45
