-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: i8d211.p.ssafy.io    Database: metassafy
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `article_file`
--

DROP TABLE IF EXISTS `article_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `article_file` (
  `file_no` int NOT NULL AUTO_INCREMENT,
  `article_no` int NOT NULL,
  `origin_name` varchar(200) NOT NULL,
  `saved_name` varchar(400) NOT NULL,
  `path` varchar(500) NOT NULL,
  PRIMARY KEY (`file_no`),
  KEY `article_no` (`article_no`),
  CONSTRAINT `article_file_ibfk_1` FOREIGN KEY (`article_no`) REFERENCES `article` (`article_no`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article_file`
--

LOCK TABLES `article_file` WRITE;
/*!40000 ALTER TABLE `article_file` DISABLE KEYS */;
INSERT INTO `article_file` VALUES (3,6,'다운로드 (5).jfif','46fd4dda-f268-4050-80cb-ae677a5ed7da다운로드 (5).jfif','https://kr.object.ncloudstorage.com/metassafy/46fd4dda-f268-4050-80cb-ae677a5ed7da다운로드 (5).jfif'),(4,11,'image-download (6).png','48cfe6c5-4167-4425-9acf-670fb510e98aimage-download (6).png','https://kr.object.ncloudstorage.com/metassafy/48cfe6c5-4167-4425-9acf-670fb510e98aimage-download (6).png'),(5,12,'dog1.jfif','51907c64-f86c-4ca4-a48d-2bf2b54037c3dog1.jfif','https://kr.object.ncloudstorage.com/metassafy/51907c64-f86c-4ca4-a48d-2bf2b54037c3dog1.jfif'),(6,11,'cheers.png','e3e4b3e5-ddd3-48f7-80af-36bc02e81335cheers.png','https://kr.object.ncloudstorage.com/metassafy/e3e4b3e5-ddd3-48f7-80af-36bc02e81335cheers.png'),(7,13,'Image Pasted at 2023-2-16 10-30.png','db39bbd8-984e-4c72-8976-2b63c87d8c61Image Pasted at 2023-2-16 10-30.png','https://kr.object.ncloudstorage.com/metassafy/db39bbd8-984e-4c72-8976-2b63c87d8c61Image Pasted at 2023-2-16 10-30.png'),(8,15,'eqwweqw.PNG','eff0676e-ec28-4919-aa5c-11a209f2ce52eqwweqw.PNG','https://kr.object.ncloudstorage.com/metassafy/eff0676e-ec28-4919-aa5c-11a209f2ce52eqwweqw.PNG'),(9,17,'image-download (4).png','15c7a295-2dc3-45f7-b70c-b4c83e05c3acimage-download (4).png','https://kr.object.ncloudstorage.com/metassafy/15c7a295-2dc3-45f7-b70c-b4c83e05c3acimage-download (4).png'),(10,18,'다운로드 (4).jfif','c9ca62e8-a4c9-4ec1-a6e4-cdddea844d7c다운로드 (4).jfif','https://kr.object.ncloudstorage.com/metassafy/c9ca62e8-a4c9-4ec1-a6e4-cdddea844d7c다운로드 (4).jfif'),(11,19,'cheers.png','6f669e46-f21f-418e-9bc0-e6f399162c96cheers.png','https://kr.object.ncloudstorage.com/metassafy/6f669e46-f21f-418e-9bc0-e6f399162c96cheers.png'),(12,20,'zz.png','259ad9ff-a7d0-4c83-b905-a7f868ecc58czz.png','https://kr.object.ncloudstorage.com/metassafy/259ad9ff-a7d0-4c83-b905-a7f868ecc58czz.png');
/*!40000 ALTER TABLE `article_file` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17  9:07:45
